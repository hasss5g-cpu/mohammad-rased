/* ============================================================
   يعمل داخل صفحة واتساب ويب: ينتظر فتح المحادثة، يرسل الرسالة،
   ويتأكد من خروجها، ثم يبلّغ الخدمة الخلفية بالنتيجة.
   ============================================================ */
(function () {
  'use strict';

  let port = null;
  let busy = false;

  function connect() {
    try {
      port = chrome.runtime.connect({ name: 'rasid-wa' });
      port.onMessage.addListener(onMsg);
      port.onDisconnect.addListener(() => { port = null; setTimeout(connect, 800); });
      port.postMessage({ cmd: 'ready' });
    } catch (e) {
      setTimeout(connect, 1000);
    }
  }

  function say(message, kind) { if (port) port.postMessage({ cmd: 'log', message: message, kind: kind }); }
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  function nowTime() {
    const d = new Date();
    let h = d.getHours();
    const ap = h < 12 ? 'ص' : 'م';
    h = h % 12; if (h === 0) h = 12;
    return h + ':' + String(d.getMinutes()).padStart(2, '0') + ' ' + ap;
  }

  function onMsg(m) {
    if (!m) return;
    if (m.type === 'task') {
      if (!m.task) return;
      handleTask(m.task);
    }
  }

  /* ---------- عناصر واجهة واتساب ---------- */
  function composer() {
    const sel = [
      'footer div[contenteditable="true"][data-lexical-editor="true"]',
      'div[contenteditable="true"][data-lexical-editor="true"]',
      'footer div[contenteditable="true"][role="textbox"]',
      'div[contenteditable="true"][role="textbox"]',
      'div[contenteditable="true"][data-tab="10"]',
      'div[contenteditable="true"][data-tab="6"]',
      'footer div[contenteditable="true"]'
    ];
    for (const s of sel) {
      const el = document.querySelector(s);
      if (el && el.offsetParent !== null) return el;
    }
    return null;
  }
  function sendButton() {
    const sel = [
      'button[aria-label="Send"]', 'button[aria-label="إرسال"]',
      'button[data-testid="send"]', '[data-testid="send"]',
      'span[data-icon="send"]',
      'div[role="button"][aria-label="Send"]', 'div[role="button"][aria-label="إرسال"]'
    ];
    for (const s of sel) {
      const el = document.querySelector(s);
      if (el) {
        const btn = el.closest('button') || el.closest('div[role="button"]') || el;
        if (btn && btn.offsetParent !== null) return btn;
      }
    }
    return null;
  }
  function dialogText() {
    const nodes = document.querySelectorAll('div[role="dialog"], [role="alert"], [data-testid="alert"]');
    return Array.from(nodes).map(n => n.innerText || '').join(' ');
  }
  function invalidReason() {
    const t = (dialogText() + ' ' + (document.body ? document.body.innerText.slice(0, 6000) : '')).toLowerCase();
    if (/phone number shared via url is invalid|invalid phone|isn't on whatsapp|is not on whatsapp|not on whatsapp|not registered|no whatsapp account|phone number is invalid/.test(t)) return 'الرقم ليس عليه واتساب';
    if (/رقم الهاتف غير صالح|رقم غير صالح|غير مسجل في واتساب|ليس (على|مسجل)|لا يوجد حساب|رقم واتساب غير/.test(t)) return 'الرقم ليس عليه واتساب';
    return '';
  }
  function loggedIn() {
    return !document.querySelector('canvas[aria-label*="Scan"]') &&
      !document.querySelector('div[data-ref] canvas') &&
      !!document.querySelector('#app, #side, header, [data-testid="chat-list"], [data-testid="conversation-panel-wrapper"]');
  }

  async function waitFor(fn, timeout, step) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeout) {
      try { const v = fn(); if (v) return v; } catch (e) { }
      await sleep(step || 300);
    }
    return null;
  }

  /* ---------- تنفيذ الإرسال ---------- */
  async function handleTask(task) {
    if (busy) return;
    busy = true;
    try {
      /* 1) انتظار تحميل واتساب ويب */
      const ready = await waitFor(loggedIn, 45000, 400);
      if (!ready) {
        if (document.querySelector('canvas')) {
          reply(task, false, 'يلزم تسجيل الدخول إلى واتساب ويب أولًا (امسح رمز QR)');
        } else {
          reply(task, false, 'لم تُحمّل صفحة واتساب ويب خلال 45 ثانية');
        }
        return;
      }
      await sleep(1200);
      say('تم فتح واتساب ويب — جارٍ تجهيز المحادثة', 'ok');

      /* 2) التأكد من صحة الرقم */
      const bad = await waitFor(() => invalidReason(), 3000, 200);
      if (bad) { reply(task, false, 'الرقم ليس عليه واتساب — تم التخطي', 'no_whatsapp'); return; }

      /* 3) انتظار صندوق الكتابة مع التخطي الفوري عند ظهور رسالة عدم التسجيل */
      const found = await waitFor(() => {
        const reason = invalidReason();
        if (reason) return { bad: reason };
        return composer();
      }, 12000, 250);
      if (found && found.bad) { reply(task, false, 'الرقم ليس عليه واتساب — تم التخطي', 'no_whatsapp'); return; }
      const box = found;
      if (!box) {
        const reason = invalidReason();
        if (reason) reply(task, false, 'الرقم ليس عليه واتساب — تم التخطي', 'no_whatsapp');
        else reply(task, false, 'لم يتم العثور على صندوق كتابة الرسالة');
        return;
      }
      say('تم العثور على صندوق الرسالة', 'ok');

      /* 4) وقفة قصيرة عشوائية داخل المحادثة (تبدو بشرية) */
      await sleep(1200 + Math.random() * 3000);

      /* 5) تجهيز النص: النص يأتي جاهزًا من رابط المحادثة، وإن لم يصل نكتبه */
      const wanted = (task.text || '').replace(/\r/g, '');
      let current = (box.innerText || '').replace(/\u200b/g, '').trim();
      if (!current && wanted) {
        box.focus();
        await sleep(200);
        document.execCommand('insertText', false, wanted);
        await sleep(400);
        current = (box.innerText || '').replace(/\u200b/g, '').trim();
      }
      if (!current) { reply(task, false, 'لم تُكتب الرسالة في صندوق المحادثة'); return; }

      /* 6) الإرسال: زر الإرسال إن وُجد، وإلا مفتاح Enter */
      const btn = sendButton();
      if (btn) { btn.click(); }
      else {
        box.focus();
        const opts = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true };
        box.dispatchEvent(new KeyboardEvent('keydown', opts));
        box.dispatchEvent(new KeyboardEvent('keypress', opts));
        box.dispatchEvent(new KeyboardEvent('keyup', opts));
      }

      /* 7) التأكد من الإرسال (فراغ الصندوق أو ظهور رسالة صادرة) */
      const ok = await waitFor(() => {
        const c = composer();
        const empty = !c || !(c.innerText || '').replace(/\u200b/g, '').trim();
        const out = document.querySelectorAll('div.message-out, [data-id*="true_"], [data-pre-plain-text]');
        return (empty && out.length > 0) || empty ? true : null;
      }, 12000, 400);

      if (ok) { say('تم إرسال الرسالة', 'ok'); reply(task, true, ''); }
      else reply(task, false, 'لم يتم تأكيد الإرسال من واتساب');
    } catch (e) {
      reply(task, false, 'خطأ: ' + (e && e.message ? e.message : e));
    } finally {
      busy = false;
    }
  }

  function reply(task, ok, detail, code) {
    if (!port) return;
    port.postMessage({ cmd: 'result', result: { sid: task.sid, ok: ok, detail: detail, code: code || '', time: ok ? nowTime() : '' } });
  }

  connect();
})();
