/* ============================================================
   حسابات التوقيت العشوائي (مشتركة بين الإضافة والاختبارات)
   الهدف: فواصل غير منتظمة — تنقص وتزيد — حتى لا يبدو الإرسال آليًا.
   ============================================================ */
(function (root) {
  'use strict';

  function rand(min, max) { return min + Math.random() * (max - min); }

  /* فاصل زمني متفاوت قبل الانتقال للطالب التالي (بالمللي ثانية) */
  function nextDelay(opts) {
    const o = opts || {};
    const min = Math.max(2, Number(o.min) || 2);
    const max = Math.min(5, Math.max(min + 1, Number(o.max) || 5));
    const sec = rand(min, max);
    return Math.max(2000, Math.min(5000, Math.round(sec * 1000)));
  }
  /* وقفة قصيرة عشوائية داخل المحادثة (قبل الضغط على إرسال) */
  function readDelay(minSec, maxSec) {
    return Math.round(rand(minSec || 1.5, maxSec || 5) * 1000);
  }

  const api = { nextDelay: nextDelay, readDelay: readDelay, rand: rand };

  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.RasidScheduler = api;
})(typeof self !== 'undefined' ? self : this);

